# micROS-cloud-client
Introduction

micROS-cloud-client is the client side of micROS-cloud(https://github.com/xiteen/micROS-cloud). With the installation of this client, the proxy of each service can be easily installed and connecting to the cloud platform.

Please contact us through siteen@outlook.com or bding@msn.com. Any feedback would be greatly appreciated.


