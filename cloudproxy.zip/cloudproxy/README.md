# Cloudroid-client(micROS-cloud-client)
Introduction
Cloudroid-client is the client side of Cloudroid(https://github.com/cyberdb/Cloudroid). With the installation of this client, the proxy of each service can be easily installed and connecting to the cloud platform.

Please contact us through siteen@outlook.com or bding@msn.com. Any feedback would be greatly appreciated.


